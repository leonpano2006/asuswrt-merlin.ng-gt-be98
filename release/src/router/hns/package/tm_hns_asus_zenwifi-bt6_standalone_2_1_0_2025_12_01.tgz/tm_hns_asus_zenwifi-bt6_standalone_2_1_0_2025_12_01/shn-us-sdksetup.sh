#!/bin/sh

PWD=$(dirname $(readlink -f $0))
CAT() { cat 2>/dev/null $@; }
KILLALL() { killall 2>/dev/null $@; }
BASENAME() { [ "$(which basename)" ] && echo $(basename $1) || echo ${1##*/}; }
export LD_LIBRARY_PATH=$PWD:$LD_LIBRARY_PATH
export UDATA_PATH=${PWD}

NCPU=$(grep '^processor' /proc/cpuinfo | sort -u | wc -l)
CMD="$1";

trap "" INT HUP TSTP QUIT

source ./shn-us-sdksetup.conf

UFWD_BIN=ufwd
UFWD_PID=ufwd.pid
UFWD_MONITOR_PID=ufwd_monitor.pid
UFWD_OPT=
if [ "$HNS_TMP_DIR" ]; then
	UFWD_BIN=$HNS_TMP_DIR/$UFWD_BIN
	UFWD_PID=$HNS_TMP_DIR/$UFWD_PID
	UFWD_MONITOR_PID=$HNS_TMP_DIR/$UFWD_MONITOR_PID
else
	UFWD_BIN=$(pwd)/$UFWD_BIN
	UFWD_PID=$(pwd)/$UFWD_PID
	UFWD_MONITOR_PID=$(pwd)/$UFWD_MONITOR_PID
fi
WAN_INF=$TMCFG_FW_WAN_INF
LAN_INF=$TMCFG_FW_LAN_INF

if [ -z "$WAN_INF" -o -z "$LAN_INF" ]; then
	echo "Error on WAN or LAN empty configuration!"
	exit 1
fi

NFQ_CHAIN="HNS-UFWD"
NFQ_QNUM=0
if [ $NCPU -gt 3 ]; then
	NFQ_QNUM=$(expr $NCPU / 2 - 1)
fi
NFQ_MARK=$(echo $((0x80000000)))
APP_TIMEOUT=86400
USER_TIMEOUT=86400

if [ "$TMCFG_UFWD_MONITOR" == "y" ]; then
	UFWD_MONITOR=$(pwd)/ufwd-monitor.sh
fi

mark_cmd()
{
	[ $NFQ_MARK -gt 0 ] && echo "-m mark ! --mark $NFQ_MARK/$NFQ_MARK" || echo ""
}

IPT_WAIT_SEC=10
IPT_WAIT_INT=100000

{
	local cmd=

	[ $IPT_WAIT_SEC -gt 0 ] && cmd="-w $IPT_WAIT_SEC" || return
	[ $IPT_WAIT_INT -gt 0 ] && cmd="$cmd -W $IPT_WAIT_INT"

	echo $cmd
}

setup_ipt()
{
	local chain=$1
	local qnum_beg=$2
	local qnum_end=$3
	local mark=$4
	local iptables=$5
	echo "Setup $iptables rules..."

	local rule_type="A"
	local connbyte_cmd="-m connbytes --connbytes-mode packets --connbytes-dir original --connbytes 0:20"

	$iptables -N $chain
	if [ $mark -gt 0 ]; then
		rule_type="I"
		$iptables -I $chain -j MARK --set-mark $mark/$mark
	fi

	if [ $qnum_beg -eq $qnum_end ]; then
		$iptables -A $chain $connbyte_cmd -j NFQUEUE --queue-num $qnum_beg --queue-bypass
	else
		$iptables -A $chain $connbyte_cmd -j NFQUEUE --queue-balance $qnum_beg:$qnum_end --queue-bypass
	fi

	$iptables -$rule_type FORWARD $(mark_cmd) -j $chain
	$iptables -$rule_type INPUT $(mark_cmd) -j $chain
	$iptables -$rule_type OUTPUT $(mark_cmd) -j $chain
}

reset_ipt()
{
	local chain=$1
	local iptables=$2
	echo "Reset $iptables rules..."

	$iptables -D FORWARD $(mark_cmd) -j $chain &> /dev/null
	$iptables -D INPUT $(mark_cmd) -j $chain &> /dev/null
	$iptables -D OUTPUT $(mark_cmd) -j $chain &> /dev/null

	$iptables -F $chain &> /dev/null
	$iptables -X $chain &> /dev/null

}

setup()
{
	reset_ipt $NFQ_CHAIN "iptables"
	if [ "$TMCFG_IPV6_ENABLED" = "y" ]; then
		reset_ipt $NFQ_CHAIN "ip6tables"
	fi

	setup_ipt $NFQ_CHAIN 0 $NFQ_QNUM $NFQ_MARK "iptables"
	if [ "$TMCFG_IPV6_ENABLED" = "y" ]; then
		setup_ipt $NFQ_CHAIN 0 $NFQ_QNUM $NFQ_MARK "ip6tables"
	fi
}

reset()
{
	reset_ipt $NFQ_CHAIN "iptables"
	if [ "$TMCFG_IPV6_ENABLED" = "y" ]; then
		reset_ipt $NFQ_CHAIN "ip6tables"
	fi
}

ufwd_cmdline()
{
	local pid=$1
	local cmd

	[ ! "$pid" -o ! -d /proc/$pid ] && { echo ""; return; }
	cmd=$(CAT /proc/$pid/cmdline | tr '\000' ' ')
	clen=`echo $cmd | wc -m`
	cmdline=`echo $cmd | cut -c-$clen`
	#echo "${cmd:0:($(echo $cmd | wc -m)-1)}"
	echo "$cmdline"
}

is_ufwd_running()
{
	local bin=$(echo $(ufwd_cmdline `CAT $UFWD_PID`) | cut -d' ' -f1)

	[ "$bin" == "$UFWD_BIN" ] && echo "yes" || echo "no"
}

do_ufwd()
{
  local cmd="$1"
  local wait_sec=20
  case "$cmd" in
	start)
		if [ "$(is_ufwd_running)" == "yes" ]; then
			echo "UFWD is already running..."
			return;
		fi
		setup
		echo "Start UDB engine..."
		UFWD_OPT="-w $WAN_INF -l $LAN_INF -q 0 -q $NFQ_QNUM -m $NFQ_MARK -a $APP_TIMEOUT -u $USER_TIMEOUT"
		# Do not run ufwd in the background
		$UFWD_BIN $UFWD_OPT
		if [ $? -ne 0 ]; then
			reset
			exit 1
		fi
		./hns_cli -e set_eula_agreed
		touch $PWD/ufwd_ok
		;;
	stop)
		if [ "$2" != "reset-system" ];then
			echo "Stop UDB engine..."
			KILLALL -INT $(BASENAME $UFWD_BIN)
			while [ $wait_sec -gt 0 ]; do
				[ "$(is_ufwd_running)" == "yes" ] && { sleep 1; wait_sec=$(($wait_sec-1)); } || break
			done
			[ "$(is_ufwd_running)" == "yes" ] && { KILLALL -KILL $(BASENAME $UFWD_BIN); rm -f $UFWD_PID; }

		fi
		reset
		rm -f $PWD/ufwd_ok
		;;
  esac
}

shn_daemon_stop()
{
	do_ufwd stop $1
}

shn_daemon_start()
{
	do_ufwd start
}

case "$CMD" in
setup)
	setup
	exit
	;;
start)
	shn_daemon_start
	if [ "$UFWD_MONITOR" ]; then
		$UFWD_MONITOR $PWD/$(BASENAME $0) "$(ufwd_cmdline `CAT $UFWD_PID`)" "$UFWD_PID" &
	fi
	exit
	;;
stop)
	if [ "$UFWD_MONITOR" -a -e $UFWD_MONITOR_PID ]; then
		kill -TERM $(CAT $UFWD_MONITOR_PID) &
	fi
	shn_daemon_stop
	exit
	;;
restart)
	# restart action doesn't equal to stop action then start action.
	# It's for ufwd-monitor usage, when ufwd is in the state what we are not expected.
	# Doing normal restart SHN, please use stop action then start action.
	shn_daemon_stop
	shn_daemon_start
	exit
	;;
reset-system)
	shn_daemon_stop reset-system 
	exit
	;;
*)
	echo "Usage: $0 {start|stop}"
	#exit
	;;
esac;

