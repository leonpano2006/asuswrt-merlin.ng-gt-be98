#!/bin/sh

CAT() { cat 2>/dev/null $@; }
BASENAME() { [ "$(which basename)" ] && echo $(basename $1) || echo ${1##*/}; }

MON_INTL=30

SHN_SCRIPT=${1}
UFWD_CMD=${2}
if [ -z "${3}" ]; then
        UFWD_PID_FILE=ufwd.pid
else
        UFWD_PID_FILE=${3}
fi

if [ -e $UFWD_PID_FILE ]; then
	UFWD_PID=`CAT $UFWD_PID_FILE`
else
	echo "***** Fatal error: '$UFWD_PID_FILE' doesn't exist. $(BASENAME $0) stopped! *****" >&2; exit 1
fi

LOCK_FILE=$(dirname $UFWD_PID_FILE)/ufwd_monitor.pid
[ -e $LOCK_FILE ] && [ "$(CAT /proc/`CAT $LOCK_FILE`/cmdline | grep $(BASENAME $0))" ] && {
	kill -USR1 `CAT $LOCK_FILE`
	exit 1
}
HNS_WAITING=/var/run/hnswait
echo "Start ufwd-monitor..."
echo $$ > $LOCK_FILE

trap stop_ufwd_monitor INT TERM
stop_ufwd_monitor()
{
	echo "Stop ufwd-monitor..."
	rm -f $LOCK_FILE
	exit 0
}

trap switch_ufwd USR1
switch_ufwd()
{
	local new_pid=`CAT $UFWD_PID_FILE`
	if [ "$new_pid" != "$UFWD_PID" ]; then
		kill 2>/dev/null -KILL $UFWD_PID
		UFWD_PID=$new_pid
		local cmd=`CAT /proc/$UFWD_PID/cmdline | tr '\000' ' '`
		local clen=`echo $cmdline | wc -m`
		local cmdline=`echo $cmdline | cut -c-$clen`
		UFWD_CMD="echo $cmdline"
	fi
}

no_ufwd_running()
{
	if [ "$UFWD_PID" ]; then
		if [ -d /proc/$UFWD_PID ]; then
			cmdline=`CAT /proc/$UFWD_PID/cmdline | tr '\000' ' '`
			clen=`echo $cmdline | wc -m`
			cmdline=`echo $cmdline | cut -c-$clen`
			if [ "$UFWD_CMD" = "$cmdline" ]; then
				return 0
			else
				return 1
			fi
		else
			return 1
		fi
	else
		return 1
	fi
}

# program monitor #
while [ true ];
do
  no_ufwd_running
  if [ $? = 1 ]; then
	$SHN_SCRIPT restart
	if [ $? -ne 0 ]; then
		continue
	fi
	switch_ufwd
  fi
  echo $$ > $LOCK_FILE
  echo $UFWD_PID > $UFWD_PID_FILE
  if [ -p $HNS_WAITING ]; then
    echo "ready" > $HNS_WAITING
  fi
  sleep $MON_INTL;
done
